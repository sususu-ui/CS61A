def run_loop(init, cond, body, done):
    def helper(state):
        if not cond(state):
            return done(state)
        return helper(body(state))
    return helper(init)

def contains_six(n):
    if n == 0:
        return False
    if n % 10 == 6:
        return True
    return contains_six(n // 10)

def switch(n):
    return n % 6 == 0 or contains_six(n)

def chain(steps):
    def chained(state):
        if steps == []:
            return state
        return chain(steps[1:])(steps[0](state))
    return chained

def mystery_loop(n):
    total, i = 0, 1
    while i <= n:
        total = total + i
        if total % 3 == 0:
            i = i + 2
        else:
            i = i + 1
    return total
