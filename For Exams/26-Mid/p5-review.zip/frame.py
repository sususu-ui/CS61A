from html import escape


def _fmt(value):
    if value is Ellipsis or value == "...":
        return "..."
    text = repr(value) if isinstance(value, str) else str(value)
    return escape(text)


def _pair(key, value, color="#222"):
    return (
        "<tr>"
        f'<td style="text-align:right;padding:2px 8px 2px 0;border:0;color:{color};">{escape(str(key))}</td>'
        f'<td style="text-align:left;padding:2px 8px;border:0;border-left:1px solid #aaaaaa;'
        f'border-bottom:1px solid #aaaaaa;color:{color};">{_fmt(value)}</td>'
        "</tr>"
    )


class Frame:
    def __init__(self, name, values, *, ret=None, active=False, caption=None):
        self.name = name
        self.values = tuple(values)
        self.ret = ret
        self.active = active
        self.caption = caption

    def _repr_html_(self):
        bg = "#e2ebf6" if self.active else "#ffffff"
        rows = [_pair(key, value) for key, value in self.values]
        if self.ret is not None:
            rows.append(_pair("Return value", self.ret, color="#e93f34"))
        frame = (
            f'<div style="display:inline-block;width:max-content;box-sizing:border-box;background:{bg};'
            "border-left:1px solid #a6b3b6;padding:2px 8px 4px;"
            'font-family:Verdana,Arial,Helvetica,sans-serif;font-size:14px;color:#222;line-height:1.25;">'
            "<div style=\"font-family:Consolas,'Courier New',monospace;margin:4px 0 2px;white-space:nowrap;\">"
            f"{escape(str(self.name))}</div>"
            '<table style="margin:0 0 0 auto;width:max-content;border-collapse:separate;border-spacing:2px;'
            'font-size:14px;line-height:1.25;">'
            + "".join(rows)
            + "</table></div>"
        )
        if self.caption is None:
            return frame
        cap = (
            '<div style="display:block;width:max-content;color:#777;font-size:12px;'
            "font-family:Verdana,Arial,sans-serif;margin:0 0 4px 0;white-space:nowrap;\">"
            f"{escape(str(self.caption))}</div>"
        )
        return (
            '<div style="display:inline-block;width:max-content;vertical-align:bottom;">'
            f"{cap}{frame}</div>"
        )

    def __repr__(self):
        return f"Frame(name={self.name!r}, values={self.values!r})"


class Frames:
    """Draw frames from top to bottom."""

    def __init__(self, *frames):
        if len(frames) == 1 and isinstance(frames[0], (tuple, list)):
            frames = tuple(frames[0])
        self.frames = tuple(frames)

    def _repr_html_(self):
        blocks = []
        for frame in self.frames:
            blocks.append(
                '<div style="display:block;width:max-content;margin:0 0 12px 0;">'
                f"{frame._repr_html_()}</div>"
            )
        return (
            '<div style="display:inline-block;width:max-content;">'
            + "".join(blocks)
            + "</div>"
        )

    def __repr__(self):
        return "Frames(" + ", ".join(repr(frame) for frame in self.frames) + ")"
